Note that these crash test are bad, because a bottleneck
is not a Realplexor, but a load-test script itself. Seems
Perl works with multiple connections in a non-event-driven
environment too inefficiently.
