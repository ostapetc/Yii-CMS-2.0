<?php

require_once "../../api/php/Dklab/Realplexor.php";
$mpl = new Dklab_Realplexor("127.0.0.1", "10010", "demo_");
