<?php
require dirname(__FILE__) . '/../../../t/servertest/init.php';

$mpl = new Dklab_Realplexor("127.0.0.1", "10010", @$NAMESPACE);
